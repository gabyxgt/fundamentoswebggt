document.getElementById("loginForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const usuario = document.getElementById("usuario").value.trim();
    const contrasena = document.getElementById("contrasena").value;

    if (usuario === "cenfo" && contrasena === "1234") {
        Swal.fire({
            imageUrl: 'img/mascot gif.GIF',
            imageWidth: 130,
            imageHeight: 150,
            imageAlt: 'Animación de éxito',
            title: '¡Login exitoso!',
            text: 'Bienvenido a Vivero Pétalo Vivo',
            confirmButtonText: 'Continuar',
            confirmButtonColor: '#75987a',
            allowOutsideClick: false,
            showClass: {
                popup: 'animate__animated animate__slideInDown'
            },
            hideClass: {
                popup: 'animate__animated animate__slideOutUp'
            }
        }).then(() => {
            window.location.href = "landing.html";
        });
    } else {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Usuario o contraseña incorrectos',
            confirmButtonText: 'Intentar de nuevo',
            confirmButtonColor: '#9d3c49',
            showClass: {
                popup: 'animate__animated animate__slideInDown'
            },
            hideClass: {
                popup: 'animate__animated animate__slideOutUp'
            }
        });
    }
});
