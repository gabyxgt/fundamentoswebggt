document.getElementById("btnFacturar").addEventListener("click", function() {
  let cliente = document.getElementById("cliente").value;
  let articulo = document.getElementById("articulo").value;
  let cantidad = parseFloat(document.getElementById("cantidad").value);
  let precio = parseFloat(document.getElementById("precio").value);

  if (!cliente || !articulo || isNaN(cantidad) || isNaN(precio) || cantidad <= 0 || precio <= 0) {
    Swal.fire("Error", "Por favor ingrese todos los datos correctamente.", "error");
    return;
  }

  let subtotal = cantidad * precio;
  let iva = subtotal * 0.13;
  let servicio = subtotal * 0.05;
  let total = subtotal + iva + servicio;

  let resultadoHTML = `
    <h3>Factura Digital</h3>
    <p><strong>Cliente:</strong> ${cliente}</p>
    <p><strong>Artículo:</strong> ${articulo}</p>
    <p><strong>Cantidad:</strong> ${cantidad}</p>
    <p><strong>Precio:</strong> ₡${precio.toFixed(2)}</p>
    <hr>
    <p><strong>Subtotal:</strong> ₡${subtotal.toFixed(2)}</p>
    <p><strong>IVA (13%):</strong> ₡${iva.toFixed(2)}</p>
    <p><strong>Servicio (5%):</strong> ₡${servicio.toFixed(2)}</p>
    <p><strong>Total a pagar:</strong> <b>₡${total.toFixed(2)}</b></p>
  `;

  document.getElementById("resultadoFactura").innerHTML = resultadoHTML;

  Swal.fire("Factura generada", "La factura ha sido calculada correctamente.", "success");
});

document.getElementById("btnBorrar").addEventListener("click", function() {
  document.getElementById("cliente").value = "";
  document.getElementById("articulo").value = "";
  document.getElementById("cantidad").value = "";
  document.getElementById("precio").value = "";
  document.getElementById("resultadoFactura").innerHTML = "";
});
