const selectDibujos = document.getElementById('Dibujos');
const imagenDibujo = document.getElementById('imagenDibujo');

selectDibujos.addEventListener('change', function() {
    const valor = this.value;

    switch(valor) {
        case 'jester':
            imagenDibujo.src = '../img/dibujo1.png'; 
            imagenDibujo.alt = 'Dibujo Jester';
            break;
        case 'crow':
            imagenDibujo.src = '../img/dibujo2.png'; 
            imagenDibujo.alt = 'Crow';
            break;
        case 'lamb':
            imagenDibujo.src = '../img/dibujo3.png'; 
            imagenDibujo.alt = 'Lamb with two heads';
            break;
        case 'fish':
            imagenDibujo.src = '../img/dibujo4.png'; 
            imagenDibujo.alt = 'Fish';
            break;
        default:
            imagenDibujo.src = '';
            imagenDibujo.alt = '';
    }
});
