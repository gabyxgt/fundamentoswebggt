const empleados = [
  {
    cedula: "109110338",
    nombre: "Tomás",
    apellidos: "Alvarado Quesada",
    lugar: "San José, Costa Rica",
    regimen: "Contributivo",
    anoIngreso: "2015",
    departamento: "Finanzas",
    foto: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=180&fit=crop&crop=face"
  },
  {
    cedula: "209110338",
    nombre: "Stephanie Priscilla",
    apellidos: "Salazar Valverde",
    lugar: "Cartago, Costa Rica",
    regimen: "No Contributivo",
    anoIngreso: "2018",
    departamento: "Recursos Humanos",
    foto: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=180&fit=crop&crop=face"
  },
  {
    cedula: "309110338",
    nombre: "Rolando Javier",
    apellidos: "Pacheco Barrantes",
    lugar: "Alajuela, Costa Rica",
    regimen: "Contributivo",
    anoIngreso: "2020",
    departamento: "Tecnología",
    foto: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=180&fit=crop&crop=face"
  },
  {
    cedula: "409110338",
    nombre: "Natalia",
    apellidos: "Blanco Obando",
    lugar: "Heredia, Costa Rica",
    regimen: "Contributivo",
    anoIngreso: "2017",
    departamento: "Marketing",
    foto: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=180&fit=crop&crop=face"
  },
  {
    cedula: "509110338",
    nombre: "Mark",
    apellidos: "Bingham",
    lugar: "Puntarenas, Costa Rica",
    regimen: "No Contributivo",
    anoIngreso: "2019",
    departamento: "Operaciones",
    foto: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=180&fit=crop&crop=face"
  }
];

document.getElementById("btnBuscar").addEventListener("click", function() {
  const cedulaIngresada = document.getElementById("cedula").value.trim();
  
  if (!cedulaIngresada) {
    Swal.fire("Error", "Por favor ingrese una cédula.", "error");
    return;
  }

  const empleadoEncontrado = empleados.find(emp => emp.cedula === cedulaIngresada);
  
  if (empleadoEncontrado) {
    mostrarInformacionEmpleado(empleadoEncontrado);
    Swal.fire("¡Encontrado!", "Empleado localizado exitosamente.", "success");
  } else {
    ocultarInformacionEmpleado();
    Swal.fire("No encontrado", "El usuario NO existe.", "warning");
  }
});

function mostrarInformacionEmpleado(empleado) {
  document.getElementById("nombre").textContent = empleado.nombre;
  document.getElementById("apellidos").textContent = empleado.apellidos;
  document.getElementById("lugar").textContent = empleado.lugar;
  document.getElementById("regimen").textContent = empleado.regimen;
  document.getElementById("anoIngreso").textContent = empleado.anoIngreso;
  document.getElementById("departamento").textContent = empleado.departamento;
  document.getElementById("fotoEmpleado").src = empleado.foto;
  
  document.getElementById("informacionEmpleado").style.display = "block";
}

function ocultarInformacionEmpleado() {
  document.getElementById("informacionEmpleado").style.display = "none";
}

document.getElementById("btnLimpiar").addEventListener("click", function() {
  document.getElementById("cedula").value = "";
  ocultarInformacionEmpleado();
});

document.getElementById("cedula").addEventListener("keypress", function(event) {
  if (event.key === "Enter") {
    document.getElementById("btnBuscar").click();
  }
});