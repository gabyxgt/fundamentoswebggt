document.getElementById("btnIr").addEventListener("click", function() {
  let menu = document.getElementById("menuSitios");
  let urlSeleccionada = menu.value;

  if (urlSeleccionada === "") {
    Swal.fire("Atención", "Por favor seleccione un sitio web del menú.", "warning");
    return;
  }

  Swal.fire({
    title: "Redirigiendo...",
    text: "Serás llevado al sitio seleccionado.",
    icon: "info",
    showConfirmButton: false,
    timer: 1500
  });

  setTimeout(() => {
    window.open(urlSeleccionada, "_blank");
  }, 1600);
});

document.getElementById("btnLimpiar").addEventListener("click", function() {
  document.getElementById("menuSitios").value = "";
});
