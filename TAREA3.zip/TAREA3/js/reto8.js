// Array para almacenar las tareas aqui
let tareas = [];

document.getElementById("btnAgregar").addEventListener("click", function() {
  const titulo = document.getElementById("titulo").value.trim();
  const descripcion = document.getElementById("descripcion").value.trim();
  const fecha = document.getElementById("fecha").value;
  const prioridad = document.getElementById("prioridad").value;

  // Validaciones!!
  if (!titulo || !descripcion || !fecha) {
    Swal.fire("Error", "Por favor completa todos los campos.", "error");
    return;
  }

  const tarea = {
    id: Date.now(),
    titulo: titulo,
    descripcion: descripcion,
    fecha: fecha,
    prioridad: prioridad
  };

  tareas.push(tarea);

  actualizarCombo();

  limpiarFormulario();

  Swal.fire("Éxito", "Tarea agregada correctamente.", "success");
});

document.getElementById("btnLimpiar").addEventListener("click", limpiarFormulario);

function limpiarFormulario() {
  document.getElementById("titulo").value = "";
  document.getElementById("descripcion").value = "";
  document.getElementById("fecha").value = "";
  document.getElementById("prioridad").value = "Baja";
}

function actualizarCombo() {
  const combo = document.getElementById("listaTareas");
  
  combo.innerHTML = '<option value="">-- Selecciona una tarea --</option>';
  
  tareas.forEach(tarea => {
    const option = document.createElement("option");
    option.value = tarea.id;
    option.textContent = `${tarea.titulo} (${tarea.prioridad})`;
    combo.appendChild(option);
  });
}

document.getElementById("listaTareas").addEventListener("change", function() {
  const tareaId = parseInt(this.value);
  const detallesDiv = document.getElementById("detallesTarea");
  
  if (!tareaId) {
    detallesDiv.style.display = "none";
    return;
  }
  
  // Buscar la tarea seleccionada
  const tareaSeleccionada = tareas.find(tarea => tarea.id === tareaId);
  
  if (tareaSeleccionada) {
    // Mostrar detalles
    document.getElementById("detalleTitulo").textContent = tareaSeleccionada.titulo;
    document.getElementById("detalleDescripcion").textContent = tareaSeleccionada.descripcion;
    document.getElementById("detalleFecha").textContent = tareaSeleccionada.fecha;
    document.getElementById("detallePrioridad").textContent = tareaSeleccionada.prioridad;
    
    // Calcular días restantes
    const fechaLimite = new Date(tareaSeleccionada.fecha);
    const fechaActual = new Date();
    const diferencia = Math.ceil((fechaLimite - fechaActual) / (1000 * 60 * 60 * 24));
    
    let textoDias;
    if (diferencia > 0) {
      textoDias = `${diferencia} días restantes`;
    } else if (diferencia === 0) {
      textoDias = "¡Vence hoy!";
    } else {
      textoDias = `Vencida hace ${Math.abs(diferencia)} días`;
    }
    
    document.getElementById("detalleDias").textContent = textoDias;
    
    // Mostrar el div de detalles
    detallesDiv.style.display = "block";
  }
});