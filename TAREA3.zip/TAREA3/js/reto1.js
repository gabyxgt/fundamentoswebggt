// --- Conversión: Dólares a Colones ---
document.getElementById("btnConvertir1").addEventListener("click", function() {
  let dolares = parseFloat(document.getElementById("dolares").value);
  let tipoCambio = parseFloat(document.getElementById("tipoCambio1").value);
  let resultadoSelect = document.getElementById("resultado1");

  if (isNaN(dolares) || isNaN(tipoCambio) || dolares <= 0 || tipoCambio <= 0) {
    Swal.fire("Error", "Por favor ingrese valores válidos.", "error");
    return;
  }

  let colones = dolares * tipoCambio;
  let textoResultado = `₡ ${colones.toFixed(2)}`;

  let option = document.createElement("option");
  option.textContent = textoResultado;
  resultadoSelect.appendChild(option);
  resultadoSelect.value = textoResultado;

  Swal.fire("Conversión Exitosa", `El monto en colones es ${textoResultado}`, "success");
});

document.getElementById("btnLimpiar1").addEventListener("click", function() {
  document.getElementById("dolares").value = "";
  document.getElementById("tipoCambio1").value = "";
  document.getElementById("resultado1").innerHTML = "<option value=''>Seleccione una conversión</option>";
});

// --- Conversión: Colones a Dólares ---
document.getElementById("btnConvertir2").addEventListener("click", function() {
  let colones = parseFloat(document.getElementById("colones").value);
  let tipoCambio = parseFloat(document.getElementById("tipoCambio2").value);
  let resultadoSelect = document.getElementById("resultado2");

  if (isNaN(colones) || isNaN(tipoCambio) || colones <= 0 || tipoCambio <= 0) {
    Swal.fire("Error", "Por favor ingrese valores válidos.", "error");
    return;
  }

  let dolares = colones / tipoCambio;
  let textoResultado = `$ ${dolares.toFixed(2)}`;

  let option = document.createElement("option");
  option.textContent = textoResultado;
  resultadoSelect.appendChild(option);
  resultadoSelect.value = textoResultado;

  Swal.fire("Conversión Exitosa", `El monto en dólares es ${textoResultado}`, "success");
});

document.getElementById("btnLimpiar2").addEventListener("click", function() {
  document.getElementById("colones").value = "";
  document.getElementById("tipoCambio2").value = "";
  document.getElementById("resultado2").innerHTML = "<option value=''>Seleccione una conversión</option>";
});
