document.addEventListener('DOMContentLoaded', function() {
    const modeloCelularSelect = document.getElementById('modeloCelular');
    const cuotasSelect = document.getElementById('cuotas');
    const btnCalcular = document.getElementById('btnCalcular');
    const btnLimpiar = document.getElementById('btnLimpiar');
    const resultadoDiv = document.getElementById('resultado');
    const imagenCelular = document.getElementById('imagenCelular');
    const detallesCredito = document.getElementById('detallesCredito');

    const precios = {
        'iphone16': 850000,
        'samsungflip6': 750000,
        'nothing3': 400000,
        'huaweitrifold': 1400000
    };

    // Imágenes de los celulares
    const imagenes = {
        'iphone16': '../img/iphone16.png',
        'samsungflip6': '../img/zlflip6.png',
        'nothing3': '../img/nothingphone.png',
        'huaweitrifold': '../img/huaweitrifold.png'
    };

    // Nombres de los celulares
    const nombres = {
        'iphone16': 'iPhone 16',
        'samsungflip6': 'Samsung Galaxy Z Flip 6',
        'nothing3': 'Nothing Phone 3',
        'huaweitrifold': 'Huawei Trifold'
    };
    function validarCampos() {
        if (!modeloCelularSelect.value) {
            Swal.fire('Error', 'Seleccione un modelo de celular', 'error');
            return false;
        }
        if (!cuotasSelect.value) {
            Swal.fire('Error', 'Seleccione el número de cuotas', 'error');
            return false;
        }
        return true;
    }

    function formatearColones(monto) {
        return new Intl.NumberFormat('es-CR', {
            style: 'currency',
            currency: 'CRC',
            minimumFractionDigits: 0
        }).format(monto);
    }

    function calcularCredito() {
        if (!validarCampos()) return;

        const modelo = modeloCelularSelect.value;
        const numCuotas = parseInt(cuotasSelect.value);
        const precio = precios[modelo];
        const cuotaMensual = precio / numCuotas;

        mostrarResultados(modelo, precio, numCuotas, cuotaMensual);
    }

    function mostrarResultados(modelo, precio, numCuotas, cuotaMensual) {
        // Mostrar imagen del celular
        imagenCelular.src = imagenes[modelo];
        imagenCelular.alt = nombres[modelo];

        const html = `
            <div class="detalles-credito">
                <h4>${nombres[modelo]}</h4>
                <p><strong>Precio total:</strong> ${formatearColones(precio)}</p>
                <p><strong>Número de cuotas:</strong> ${numCuotas} meses</p>
                <p><strong>Cuota mensual:</strong> ${formatearColones(cuotaMensual)}</p>
            </div>
        `;

        detallesCredito.innerHTML = html;
        resultadoDiv.style.display = 'block';
        resultadoDiv.scrollIntoView({ behavior: 'smooth' });
    }
    function limpiarFormulario() {
        modeloCelularSelect.value = '';
        cuotasSelect.value = '';
        resultadoDiv.style.display = 'none';
        
        Swal.fire('Limpiado', 'Formulario reseteado', 'success');
    }
    btnCalcular.addEventListener('click', calcularCredito);
    btnLimpiar.addEventListener('click', limpiarFormulario);
});