let votos = [];
let votantes = [];

document.getElementById("btnVotar").addEventListener("click", function() {
  const nombre = document.getElementById("nombre").value.trim();
  const cedula = document.getElementById("cedula").value.trim();
  const correo = document.getElementById("correo").value.trim();
  const nacimiento = document.getElementById("nacimiento").value;
  const partido = document.getElementById("partido").value;

  if (!nombre || !cedula || !correo || !nacimiento || !partido) {
    Swal.fire("Error", "Por favor complete todos los campos.", "error");
    return;
  }
  if (votantes.find(v => v.cedula === cedula)) {
    Swal.fire("Error", "Esta cédula ya ha votado anteriormente.", "error");
    return;
  }

  const votante = {
    nombre: nombre,
    cedula: cedula,
    correo: correo,
    nacimiento: nacimiento,
    partido: partido,
    fechaVoto: new Date().toLocaleString()
  };

  votantes.push(votante);
  
  const votoExistente = votos.find(v => v.partido === partido);
  if (votoExistente) {
    votoExistente.cantidad++;
  } else {
    votos.push({ partido: partido, cantidad: 1 });
  }

  limpiarFormulario();

  Swal.fire("Éxito!", "Voto registrado con éxito.", "success");
});

document.getElementById("btnLimpiar").addEventListener("click", limpiarFormulario);

function limpiarFormulario() {
  document.getElementById("nombre").value = "";
  document.getElementById("cedula").value = "";
  document.getElementById("correo").value = "";
  document.getElementById("nacimiento").value = "";
  document.getElementById("partido").value = "";
}

document.getElementById("btnResultados").addEventListener("click", function() {
  const resultadosDiv = document.getElementById("resultados");
  const conteoDiv = document.getElementById("conteoVotos");
  const totalSpan = document.getElementById("totalVotantes");
  
  if (votos.length === 0) {
    Swal.fire("Info", "No hay votos registrados aún.", "info");
    return;
  }

  let htmlResultados = "";
  votos.forEach(voto => {
    const porcentaje = ((voto.cantidad / votantes.length) * 100).toFixed(1);
    htmlResultados += `
      <p><strong>${voto.partido}:</strong> ${voto.cantidad} votos (${porcentaje}%)</p>
    `;
  });

  conteoDiv.innerHTML = htmlResultados;
  totalSpan.textContent = votantes.length;
  
  resultadosDiv.style.display = "block";
  document.getElementById("listaVotantes").style.display = "none";
});

document.getElementById("btnVotantes").addEventListener("click", function() {
  const listaDiv = document.getElementById("listaVotantes");
  const votantesDiv = document.getElementById("votantesRegistrados");
  
  if (votantes.length === 0) {
    Swal.fire("Info", "No hay votantes registrados aún.", "info");
    return;
  }

  let htmlVotantes = "";
  votantes.forEach((votante, index) => {
    htmlVotantes += `
      <div style="border-bottom: 1px solid #ccc; padding: 10px 0;">
        <p><strong>${index + 1}. ${votante.nombre}</strong></p>
        <p>Cédula: ${votante.cedula} | Email: ${votante.correo}</p>
        <p>Votó por: <strong>${votante.partido}</strong></p>
        <p>Fecha de voto: ${votante.fechaVoto}</p>
      </div>
    `;
  });

  votantesDiv.innerHTML = htmlVotantes;
  
  listaDiv.style.display = "block";
  document.getElementById("resultados").style.display = "none";
});