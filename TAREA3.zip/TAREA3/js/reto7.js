const areas = document.querySelectorAll('area');

areas.forEach(area => {
  area.addEventListener('mouseover', () => {
    const provincia = area.alt;
    const info = area.dataset.info;

    Swal.fire({
      title: provincia,
      text: info,
      icon: 'info',
      timer: 980,
      showConfirmButton: false,
      position: 'top',
      width: '300px',
      customClass: {
        title: 'swal-title-small',
        content: 'swal-text-small'
      }
    });
  });
});