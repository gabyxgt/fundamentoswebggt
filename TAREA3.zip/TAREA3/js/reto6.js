const imgBolso = document.getElementById('imgBolso');
const colorRadios = document.querySelectorAll('input[name="colorBolso"]');

colorRadios.forEach(radio => {
    radio.addEventListener('change', function() {
        const color = this.value;
        imgBolso.src = `../img/bag${color}.png`;
        imgBolso.alt = `Bolso color ${color}`;
    });
});
